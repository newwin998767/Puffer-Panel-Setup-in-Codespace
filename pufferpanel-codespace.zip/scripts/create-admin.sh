#!/usr/bin/env bash
# Creates a PufferPanel user. Run this once after the panel first comes up.
# It will interactively ask for username, email, password, and whether the
# user should be an admin (answer 'y' for your main account).
set -euo pipefail

if ! docker ps --format '{{.Names}}' | grep -q '^pufferpanel$'; then
  echo "pufferpanel container is not running. Start it first:"
  echo "  bash .devcontainer/scripts/start-pufferpanel.sh"
  exit 1
fi

docker exec -it pufferpanel pufferpanel user add
