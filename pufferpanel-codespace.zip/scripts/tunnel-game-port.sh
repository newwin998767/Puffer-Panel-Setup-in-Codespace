#!/usr/bin/env bash
# GitHub Codespaces only forwards HTTP(S) ports through its port-forwarding UI —
# it does not do arbitrary raw TCP forwarding, which is what game servers like
# Minecraft need (default port 25565). This script opens a free Pinggy TCP
# tunnel to a local port so players outside the Codespace can connect.
#
# Usage:
#   bash scripts/tunnel-game-port.sh            # tunnels port 25565 (Minecraft default)
#   bash scripts/tunnel-game-port.sh 25566       # tunnels a custom port
#
# Pinggy will print a public "tcp://..." address — give that address (host:port)
# to players instead of the Codespace's own address.
#
# Note: this is a free, best-effort tunnel meant for testing. The address
# changes every time you reconnect, and the tunnel closes if the Codespace
# stops or the SSH session drops.
set -euo pipefail

PORT="${1:-25565}"

echo "==> Opening Pinggy TCP tunnel to localhost:${PORT}"
echo "    (Ctrl+C to stop the tunnel)"
echo ""

ssh -p 443 \
  -o StrictHostKeyChecking=no \
  -o ServerAliveInterval=30 \
  -R0:localhost:"${PORT}" \
  tcp@free.pinggy.io
