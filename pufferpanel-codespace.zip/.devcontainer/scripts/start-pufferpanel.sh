#!/usr/bin/env bash
# Runs every time the Codespace starts/resumes (postStartCommand).
# Codespaces stops all containers whenever the Codespace itself stops,
# so we need to make sure Docker is up and the pufferpanel container is running again.
set -euo pipefail

echo "==> Waiting for Docker daemon..."
for i in $(seq 1 30); do
  if docker info >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

if ! docker info >/dev/null 2>&1; then
  echo "Docker daemon not available yet, skipping auto-start (run scripts/setup-pufferpanel.sh manually if needed)."
  exit 0
fi

if docker ps -a --format '{{.Names}}' | grep -q '^pufferpanel$'; then
  if docker ps --format '{{.Names}}' | grep -q '^pufferpanel$'; then
    echo "==> pufferpanel container already running"
  else
    echo "==> Starting existing pufferpanel container"
    docker start pufferpanel
  fi
else
  echo "==> No pufferpanel container found. Run: bash .devcontainer/scripts/setup-pufferpanel.sh"
fi

docker ps --filter "name=pufferpanel"
