#!/usr/bin/env bash
# Runs once when the Codespace is first created (onCreateCommand).
# Pulls PufferPanel, creates persistent volumes/folders, and starts the container.
set -euo pipefail

echo "==> Waiting for Docker daemon..."
for i in $(seq 1 30); do
  if docker info >/dev/null 2>&1; then
    break
  fi
  sleep 1
done
docker info >/dev/null 2>&1 || { echo "Docker did not start in time"; exit 1; }

echo "==> Creating persistent folders (survive Codespace rebuilds since they're in /workspaces)"
mkdir -p "$(pwd)/pufferpanel-data"

echo "==> Creating Docker volume for PufferPanel config"
docker volume create pufferpanel-config >/dev/null

echo "==> Pulling PufferPanel image"
docker pull pufferpanel/pufferpanel:latest

# If a container already exists (e.g. Codespace was rebuilt but volumes persisted), skip creation.
if docker ps -a --format '{{.Names}}' | grep -q '^pufferpanel$'; then
  echo "==> Container 'pufferpanel' already exists, skipping create"
else
  echo "==> Creating PufferPanel container"
  docker run -d \
    --name pufferpanel \
    -p 8080:8080 \
    -p 5657:5657 \
    -v pufferpanel-config:/etc/pufferpanel \
    -v "$(pwd)/pufferpanel-data:/var/lib/pufferpanel" \
    -v /var/run/docker.sock:/var/run/docker.sock \
    --restart unless-stopped \
    pufferpanel/pufferpanel:latest
fi

echo "==> Waiting for PufferPanel to boot..."
sleep 5

echo ""
echo "======================================================"
echo " PufferPanel container is up."
echo ""
echo " Next steps:"
echo "  1. Create your admin user:"
echo "     bash scripts/create-admin.sh"
echo ""
echo "  2. Open the 'Ports' tab in Codespaces, set port 8080"
echo "     visibility to Public, then open its forwarded URL."
echo "======================================================"
